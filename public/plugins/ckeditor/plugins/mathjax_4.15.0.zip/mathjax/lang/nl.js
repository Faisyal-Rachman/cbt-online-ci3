/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'nl', {
	title: 'Wiskunde in TeX',
	button: 'Wiskunde',
	dialogInput: 'Typ hier uw TeX',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX documentatie',
	loading: 'laden...',
	pathName: 'wiskunde'
} );
